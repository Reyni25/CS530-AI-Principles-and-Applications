"""
Weights initializer utilities.

This module provides a simple function to create random initial weights
for a dataset, with minimal validation and reproducible seeding.
"""

import numpy as np
from typing import List


def create_weights(data: np.ndarray, activation: str = 'sigmoid', seed: int | None = None) -> List[float]:
    """
    Create a list of randomly-initialized weights for `data`.

    Inputs:
    - data: np.ndarray of shape (N, D) or (D,) representing dataset or a single
      feature vector. Must be numeric and have at least one feature.
    - activation: string, either 'sigmoid' or 'relu'. Determines weight scale.
    - seed: optional integer RNG seed for reproducibility.

    Outputs:
    - list of floats of length D (number of features)

    Purpose:
    - Provide a simple, reproducible method to initialize weights for experiments.
      Uses a small initialization scale for sigmoid and a slightly larger scale
      for ReLU to match common heuristics.

    Exceptions:
    - ValueError if `data` is not a numpy array or has invalid shape.
    - ValueError if `activation` is not supported.
    """
    if not isinstance(data, np.ndarray):
        raise ValueError("`data` must be a NumPy array")

    if data.ndim == 1:
        D = data.shape[0]
    elif data.ndim == 2:
        D = data.shape[1]
    else:
        raise ValueError("`data` must be 1-D or 2-D array")

    if D <= 0:
        raise ValueError("`data` must have at least one feature")

    if activation not in ("sigmoid", "relu"):
        raise ValueError("`activation` must be 'sigmoid' or 'relu'")

    rng = np.random.default_rng(seed)

    # Heuristic scales: smaller for sigmoid, slightly larger for relu
    scale = 0.1 if activation == "sigmoid" else 0.2
    weights = rng.normal(loc=0.0, scale=scale, size=(D,))
    return [float(w) for w in weights]
