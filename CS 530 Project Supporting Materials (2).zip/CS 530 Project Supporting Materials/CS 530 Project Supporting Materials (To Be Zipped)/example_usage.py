"""
Example usage for synthetic dataset, weight initializer, and binary classifier.

Demonstrates:
- create_synthetic_dataset
- create_weights
- binary_classifier
"""

import os
import sys

# Ensure local project directory is on sys.path for imports
sys.path.insert(0, os.path.dirname(__file__))

from synthetic_dataset import create_synthetic_dataset
from weights_initializer import create_weights
from binary_classifier import binary_classifier


def main():
    # create a small synthetic dataset
    X, y = create_synthetic_dataset(num_samples=10, input_size=3, seed=123)

    # initialize weights matching input dimension
    weights = create_weights(X, activation='sigmoid', seed=123)
    bias = 0.0

    # run classifier
    preds = binary_classifier(X, weights, bias, activation='sigmoid')

    print("y:", y)
    print("preds:", preds)


if __name__ == '__main__':
    main()
