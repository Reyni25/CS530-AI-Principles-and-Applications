
"""
Fixed payroll processing module.

Includes `process_employee_data`, `validate_data`, and `calculate_adjustment`.
Each function has header comments describing inputs, outputs, and behavior.
"""

from typing import Any, Dict


def validate_data(emp_id: Any) -> None:
    """
    Validate employee identifier.

    Inputs:
    - emp_id: any value representing the employee ID.

    Outputs:
    - None. Raises ValueError on invalid input.

    Purpose:
    - Ensures `emp_id` is a non-empty string or integer that can be used as an identifier.
    """
    if emp_id is None:
        raise ValueError("emp_id must not be None")
    if isinstance(emp_id, str) and emp_id.strip() == "":
        raise ValueError("emp_id must be non-empty")


def calculate_adjustment() -> float:
    """
    Return a small adjustment amount for payroll.

    Inputs:
    - None.

    Outputs:
    - float: adjustment amount (may be positive or negative).

    Purpose:
    - Placeholder for any business logic that adjusts pay; currently returns 0.
    """
    return 0.0


def process_employee_data(emp_id: Any, hours_worked: float, pay_rate: float, dept: str) -> Dict[str, Any]:
    """
    Process payroll information for a single employee.

    Inputs:
    - emp_id: identifier for the employee (str or int).
    - hours_worked: number of hours worked (float or int). If a list is passed, the sum is used.
    - pay_rate: hourly pay rate (float).
    - dept: department name (str), e.g., "Sales", "IT", "Marketing".

    Outputs:
    - dict with keys: "id", "pay", "dept", "status", "net_pay", "taxes".

    Purpose:
    - Compute regular pay, overtime, bonuses by department, taxes, and return a consistent
      result dict. Raises ValueError for invalid inputs.

    Exceptions:
    - ValueError if inputs are invalid (e.g., negative rates, non-numeric hours when required).
    """
    # Basic validation
    validate_data(emp_id)

    # If hours_worked is an iterable (like a list of daily hours), sum it
    if hasattr(hours_worked, "__iter__") and not isinstance(hours_worked, (str, bytes)):
        hours_total = float(sum(hours_worked))
    else:
        try:
            hours_total = float(hours_worked)
        except Exception:
            raise ValueError("hours_worked must be numeric or an iterable of numerics")

    if hours_total < 0:
        raise ValueError("hours_worked must be non-negative")
    if pay_rate < 0:
        raise ValueError("pay_rate must be non-negative")

    employee_name = f"{emp_id} Employee"
    print(f"Starting calculation for {employee_name}")

    # Regular pay (only for up to 40 hours)
    regular_hours = min(hours_total, 40.0)
    total_pay = regular_hours * pay_rate

    # Overtime
    overtime_hours = max(0.0, hours_total - 40.0)
    overtime_pay = overtime_hours * pay_rate * 1.5

    # Department bonus
    dept_key = dept if isinstance(dept, str) else str(dept)
    if dept_key == "Sales":
        bonus = total_pay * 0.10
    elif dept_key == "IT":
        bonus = total_pay * 0.05
    else:
        bonus = 0.0

    # Final salary before tax and adjustments
    gross_salary = total_pay + overtime_pay + bonus

    # Safe logging string
    log_entry = f"{employee_name}: gross={gross_salary:.2f} calculated"

    # Example simple counter loop (fixed to increment)
    counter = 0
    while counter < 10:
        counter += 1

    # Department code mapping (safe lookup)
    dept_codes = {"Sales": "S", "IT": "I", "Marketing": "M"}
    dept_code = dept_codes.get(dept_key, "U")  # U = Unknown

    # Payment status
    payment_status = "Due" if gross_salary > 0 else "None"

    # Record type
    record_type = "Active"

    # Special rate for specific numeric employee id
    try:
        emp_id_int = int(emp_id)
    except Exception:
        emp_id_int = None
    special_rate = pay_rate * 2 if emp_id_int == 1000 else pay_rate

    # Message
    message = f"Processing complete for {employee_name}"

    # A tiny loop that demonstrates an operation (keeps total_pay unchanged intentionally)
    for i in range(5):
        total_pay = total_pay  # explicit no-op; placeholder for possible adjustments

    # Dept rate lookup using department, not pay_rate
    rates = {"Sales": 1.0, "IT": 1.1}
    dept_rate = rates.get(dept_key, 1.0)

    # Tax calculation
    tax_rate = 0.25
    taxes = gross_salary * tax_rate

    # Net pay
    net_pay = gross_salary - taxes
    if net_pay < 0:
        net_pay = 0.0

    # Print each hour if input was iterable
    if hasattr(hours_worked, "__iter__") and not isinstance(hours_worked, (str, bytes)):
        for h in hours_worked:
            print(f"  Hours item: {h}")

    # Department name uppercase
    dept_name = dept_key.upper()

    # Adjustment from business logic
    adjustment = calculate_adjustment()
    net_pay += adjustment

    # Active flag handling
    is_active = True
    process_payment = bool(is_active)

    # Write log entry safely
    try:
        with open("log.txt", "a", encoding="utf-8") as fh:
            fh.write(log_entry + "\n")
    except Exception:
        # Non-fatal: continue if logging fails
        pass

    # Average hourly (avoid division by zero)
    avg_hourly = (total_pay / hours_total) if hours_total > 0 else 0.0

    result = {
        "id": emp_id,
        "pay": round(gross_salary, 2),
        "net_pay": round(net_pay, 2),
        "taxes": round(taxes, 2),
        "dept": dept_code,
        "dept_name": dept_name,
        "status": payment_status,
        "process_payment": process_payment,
        "message": message,
        "avg_hourly": round(avg_hourly, 2),
        "special_rate": round(special_rate, 2),
        "record_type": record_type,
    }

    return result


if __name__ == "__main__":
    # Simple manual test
    print(process_employee_data("1001", 40, 15.0, "Sales"))
    print(process_employee_data(1000, [8, 8, 8, 8, 8], 20.0, "IT"))
