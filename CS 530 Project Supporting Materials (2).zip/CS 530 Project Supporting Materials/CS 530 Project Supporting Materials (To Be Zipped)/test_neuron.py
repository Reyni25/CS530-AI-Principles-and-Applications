from neuron import neuron, binary_classifier


# Single neuron tests
out1 = neuron([0.5, -1.2], [0.3, 0.8], 0.1, activation='sigmoid')
print("Sigmoid output:", out1)

out2 = neuron([1.0, 2.0], [0.5, -0.5], 0.0, activation='relu')
print("ReLU output:", out2)

# Binary classifier test
data = [[0.5, -1.2], [1.0, 2.0], [-0.5, 0.1]]
weights = [0.3, 0.8]
bias = 0.1

preds_sigmoid = binary_classifier(data, weights, bias, activation='sigmoid')
print("Sigmoid predictions:", preds_sigmoid)

preds_relu = binary_classifier(data, weights, bias, activation='relu')
print("ReLU predictions:", preds_relu)