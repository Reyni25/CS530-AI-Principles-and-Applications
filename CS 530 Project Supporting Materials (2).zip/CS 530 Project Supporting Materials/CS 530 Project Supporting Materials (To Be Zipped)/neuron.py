import numpy as np

def neuron(inputs, weights, bias, activation='sigmoid'):
    """
    Single neuron forward evaluation with selectable activation.

    Inputs:
    - inputs (list or np.ndarray): 1-D sequence of numeric input features.
    - weights (list or np.ndarray): 1-D sequence of numeric weights (same length as `inputs`).
    - bias (float): Scalar bias term added to the weighted sum.
    - activation (str): Activation to apply; either 'sigmoid' or 'relu'.

    Outputs:
    - float: The scalar neuron output after applying the activation.

    Purpose:
    - Compute z = dot(inputs, weights) + bias, then apply the chosen activation.

    Exceptions:
    - Raises ValueError if `inputs` and `weights` have different shapes or if
      `activation` is not 'sigmoid' or 'relu'.
    - Raises TypeError for non-numeric bias that cannot be cast to float.
    """
    x = np.asarray(inputs, dtype=float)
    w = np.asarray(weights, dtype=float)

    if x.shape != w.shape:
        raise ValueError("`inputs` and `weights` must have the same shape")

    try:
        b = float(bias)
    except Exception:
        raise TypeError("`bias` must be numeric and convertible to float")

    z = float(np.dot(x, w) + b)

    if activation == 'sigmoid':
        return 1.0 / (1.0 + np.exp(-z))
    elif activation == 'relu':
        return z if z > 0.0 else 0.0
    else:
        raise ValueError("`activation` must be either 'sigmoid' or 'relu'")

# keep basic smoke tests local to this module
if __name__ != "__main__":
    # expose binary_classifier from the separate module so tests importing
    # `binary_classifier` from `neuron` succeed (convenience alias)
    try:
        from binary_classifier import binary_classifier  # type: ignore
    except Exception:
        # if import fails, do not break module import
        pass

if __name__ == "__main__":
    out1 = neuron([0.5, -1.2], [0.3, 0.8], 0.1, activation='sigmoid')
    out2 = neuron([1.0, 2.0], [0.5, -0.5], 0.0, activation='relu')
    print("Sigmoid output:", out1)
    print("ReLU output:", out2)