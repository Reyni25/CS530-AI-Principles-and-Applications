import numpy as np
from typing import Sequence, List

def neuron(inputs: Sequence[float], weights: Sequence[float], bias: float, activation: str = 'sigmoid') -> float:
    """
    Single neuron forward evaluation with selectable activation.

    Inputs:
    - inputs: list or np.ndarray of numeric inputs (shape (n,))
    - weights: list or np.ndarray of numeric weights (shape (n,))
    - bias: numeric bias term
    - activation: 'sigmoid' or 'relu'

    Outputs:
    - float: scalar neuron output after activation

    Purpose:
    - Compute z = dot(inputs, weights) + bias and apply activation.

    Exceptions:
    - ValueError if shapes mismatch or activation is invalid.
    - TypeError if bias is not numeric.
    """
    x = np.asarray(inputs, dtype=float)
    w = np.asarray(weights, dtype=float)
    if x.shape != w.shape:
        raise ValueError("`inputs` and `weights` must have the same shape")
    try:
        b = float(bias)
    except Exception:
        raise TypeError("`bias` must be numeric")
    z = float(np.dot(x, w) + b)
    if activation == 'sigmoid':
        return 1.0 / (1.0 + np.exp(-z))
    if activation == 'relu':
        return z if z > 0.0 else 0.0
    raise ValueError("`activation` must be either 'sigmoid' or 'relu'")

def binary_classifier(data: Sequence[Sequence[float]], weights: Sequence[float], bias: float, activation: str = 'sigmoid') -> List[int]:
    """
    Binary classifier using a single neuron applied to each input vector.

    Inputs:
    - data: iterable of input vectors (each a list/array of numeric features)
    - weights: list/array of weights (length must match each input vector)
    - bias: float bias for the neuron
    - activation: 'sigmoid' or 'relu' controlling the neuron's activation

    Outputs:
    - list of int labels (0 or 1), one per input vector in `data`

    Purpose:
    - Compute the neuron's scalar output for each input and convert it into
      a binary label. For 'sigmoid', threshold is 0.5; for 'relu', threshold is >0.0.

    Exceptions:
    - ValueError if an input vector's shape doesn't match `weights`.
    - ValueError if `activation` is not supported.
    - TypeError if numeric conversion fails for bias or inputs.
    """
    labels: List[int] = []
    for x in data:
        out = neuron(x, weights, bias, activation=activation)
        if activation == 'sigmoid':
            label = 1 if out >= 0.5 else 0
        else:  # relu
            label = 1 if out > 0.0 else 0
        labels.append(int(label))
    return labels

# Example usage:
# preds = binary_classifier([[0.5, -1.2], [1.0, 2.0]], [0.3, 0.8], 0.1, activation='sigmoid')

if __name__ == "__main__":
    # Example input data
    data = [[0.5, -1.2], [1.0, 2.0], [-0.5, 0.1]]
    weights = [0.3, 0.8]
    bias = 0.1

    # Run binary classifier with sigmoid
    preds_sigmoid = binary_classifier(data, weights, bias, activation='sigmoid')
    print("Sigmoid predictions:", preds_sigmoid)

    # Run binary classifier with ReLU
    preds_relu = binary_classifier(data, weights, bias, activation='relu')
    print("ReLU predictions:", preds_relu)