
import numpy as np

try:
    from scipy import optimize
except Exception:
    optimize = None


def a(x):
    """Sigmoid activation.

    Inputs:
    - x: np.ndarray of any shape (pre-activation values)

    Outputs:
    - sigmoid(x) evaluated elementwise, same shape as x

    Purpose:
    - Provide a numerically-stable sigmoid activation for the network.
    """
    return 1.0 / (1.0 + np.exp(-x))


def da(x):
    """Derivative of the sigmoid function.

    Inputs:
    - x: np.ndarray of any shape (pre-activation values)

    Outputs:
    - derivative of sigmoid evaluated elementwise, same shape as x

    Purpose:
    - Used during backpropagation to compute gradients.
    """
    s = a(x)
    return s * (1.0 - s)


def f(params, X, L1, L2, L3):
    """Forward pass: compute network output for inputs X.

    Inputs:
    - params: 1D parameter vector containing [w1_flat, b1, w2_flat, b2]
    - X: input data matrix of shape (N, L1)
    - L1: input dimension
    - L2: hidden layer size
    - L3: output dimension

    Outputs:
    - out: network predictions of shape (N, L3)

    Purpose:
    - Reconstruct weight/bias matrices from params and compute a forward pass
      through a single hidden-layer sigmoid network.
    """
    w1 = params[: L1 * L2].reshape(L1, L2)
    b1 = params[L1 * L2 : L1 * L2 + L2]
    w2 = params[L1 * L2 + L2 : L1 * L2 + L2 + L2 * L3].reshape(L2, L3)
    b2 = params[-L3:]

    z1 = X.dot(w1) + b1
    h = a(z1)
    z2 = h.dot(w2) + b2
    out = a(z2)
    return out


def loss(params, X, y, L1, L2, L3):
    """Mean-squared error loss.

    Inputs:
    - params: 1D parameter vector
    - X: input data of shape (N, L1)
    - y: target data of shape (N, L3)
    - L1, L2, L3: layer sizes

    Outputs:
    - scalar mean squared error between predictions and targets

    Purpose:
    - Provide a scalar loss value for the optimizer.
    """
    pred = f(params, X, L1, L2, L3)
    return np.mean((pred - y) ** 2)


def grad(params, X, y, L1, L2, L3):
    """Analytic gradient of the loss w.r.t. params using backpropagation.

    Inputs:
    - params: 1D parameter vector containing weights and biases
    - X: input data (N, L1)
    - y: targets (N, L3)
    - L1, L2, L3: layer sizes

    Outputs:
    - g: 1D gradient vector with same shape as params

    Purpose:
    - Supply the optimizer with the Jacobian (gradient) of the loss so
      optimization converges efficiently.
    """
    N = X.shape[0]
    # Reconstruct parameters
    w1 = params[: L1 * L2].reshape(L1, L2)
    b1 = params[L1 * L2 : L1 * L2 + L2]
    w2 = params[L1 * L2 + L2 : L1 * L2 + L2 + L2 * L3].reshape(L2, L3)
    b2 = params[-L3:]

    # Forward pass (we need pre-activations for derivatives)
    z1 = X.dot(w1) + b1
    h = a(z1)
    z2 = h.dot(w2) + b2
    out = a(z2)

    # dLoss/dOut for MSE: (2/N) * (out - y)
    dloss_dout = (2.0 / N) * (out - y)

    # Backprop through output sigmoid
    delta2 = dloss_dout * da(z2)  # shape (N, L3)
    gw2 = h.T.dot(delta2)  # shape (L2, L3)
    gb2 = np.sum(delta2, axis=0)  # shape (L3,)

    # Backprop to hidden layer
    delta1 = delta2.dot(w2.T) * da(z1)  # shape (N, L2)
    gw1 = X.T.dot(delta1)  # shape (L1, L2)
    gb1 = np.sum(delta1, axis=0)  # shape (L2,)

    # Flatten gradients in the same order as params: w1_flat, b1, w2_flat, b2
    g = np.concatenate([gw1.ravel(), gb1.ravel(), gw2.ravel(), gb2.ravel()])
    return g


def train_and_report():
    # Dataset
    X = np.array([[0, 0, 1], [0, 1, 1], [1, 0, 1], [1, 1, 1]], dtype=float)
    y = np.array([[0], [1], [1], [0]], dtype=float)

    L1 = 3
    L2 = 4
    L3 = 1

    rng = np.random.RandomState(1)
    w1 = rng.randn(L1 * L2)
    w2 = rng.randn(L2 * L3)
    b1 = np.zeros(L2)
    b2 = np.zeros(L3)

    params = np.concatenate([w1, b1, w2, b2])

    if optimize is not None:
        result = optimize.minimize(
            lambda p, X, y: loss(p, X, y, L1, L2, L3),
            params,
            args=(X, y),
            method="L-BFGS-B",
            jac=lambda p, X, y: grad(p, X, y, L1, L2, L3),
            options={"maxiter": 1000, "disp": True},
        )
        opt_params = result.x
    else:
        # Fallback: simple gradient descent if SciPy is not available
        opt_params = params.copy()
        lr = 1.0
        for i in range(10000):
            g = grad(opt_params, X, y, L1, L2, L3)
            opt_params -= lr * g
            if i % 1000 == 0:
                print(f"Iter {i}, loss={loss(opt_params, X, y, L1, L2, L3):.6f}")

    # Test prediction
    test = np.array([[0, 0, 1]], dtype=float)
    pred = f(opt_params, test, L1, L2, L3)
    print("Test:", pred)

    print("\nAll:")
    print(f(opt_params, X, L1, L2, L3))


if __name__ == "__main__":
    train_and_report()
