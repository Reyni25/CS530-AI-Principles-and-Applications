import numpy as np

def create_synthetic_dataset(num_samples: int, input_size: int, seed: int | None = None):
    """
    Create a synthetic binary classification dataset.

    Inputs:
    - num_samples (int): number of samples to generate (must be positive).
    - input_size (int): dimensionality of each input vector (must be positive).
    - seed (int or None): optional RNG seed for reproducibility.

    Outputs:
    - (X, y):
      - X: np.ndarray of shape (num_samples, input_size) with float features.
      - y: np.ndarray of shape (num_samples,) with binary labels {0,1}.

    Purpose:
    - Quickly produce random feature matrices and binary labels for testing models.

    Exceptions:
    - Raises ValueError if `num_samples` or `input_size` are not positive integers.
    """
    if not (isinstance(num_samples, int) and num_samples > 0):
        raise ValueError("num_samples must be a positive integer")
    if not (isinstance(input_size, int) and input_size > 0):
        raise ValueError("input_size must be a positive integer")

    rng = np.random.default_rng(seed)
    X = rng.normal(loc=0.0, scale=1.0, size=(num_samples, input_size))
    y = rng.integers(0, 2, size=(num_samples,), dtype=np.int64)
    return X, y

X, y = create_synthetic_dataset(100, 5, seed=42)